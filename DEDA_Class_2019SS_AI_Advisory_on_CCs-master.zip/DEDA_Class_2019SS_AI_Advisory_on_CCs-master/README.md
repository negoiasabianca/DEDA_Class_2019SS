[<img src="https://github.com/QuantLet/Styleguide-and-FAQ/blob/master/pictures/banner.png" width="888" alt="Visit QuantNet">](http://quantlet.de/)

# Artificial Intelligence Advisory in Finance

```yaml
Data:                             Hourly Returns of the Cryptocurrencies Bitcoin, Litecoin, Ethereum and Dash
Machine Learning Algorithm:       Long short-term memory (LSTM) Neural Networks
Portfolio Optimization Technique: using CVaR
```
